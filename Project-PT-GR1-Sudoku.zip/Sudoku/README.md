## sudoku-react

Sodoku game with React and Typescript.

### Preview Online

[Play/Solve Sudoku](https://cenxky.github.io/sudoku-react)

### License

Released under the [MIT](http://opensource.org/licenses/MIT) license. See LICENSE file for details.
